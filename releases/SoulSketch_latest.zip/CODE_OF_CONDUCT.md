# Code of Conduct

We are committed to a welcoming, professional, and respectful environment.

- Be respectful and inclusive.
- Assume good intent; address issues constructively.
- No harassment or discriminatory behavior.
- Follow repository policies, including the Sacred Separation Policy.

Enforcement: Maintainers may take appropriate action for violations.

Contact: Open a confidential issue or contact the maintainer.
