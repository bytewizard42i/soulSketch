#!/bin/bash

# Alice Memory Pack Backup Script
# Archives snapshots in /archives/ on each milestone

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MEMORY_PACK_DIR="$(dirname "$SCRIPT_DIR")"
ARCHIVES_DIR="$MEMORY_PACK_DIR/archives"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")

# Get milestone name from argument or prompt
MILESTONE="$1"
if [ -z "$MILESTONE" ]; then
    echo "Enter milestone name (e.g., 'v1.0-soul-merge', 'v1.1-soulsketch-transfer'):"
    read -r MILESTONE
fi

# Sanitize milestone name for filename
SAFE_MILESTONE=$(echo "$MILESTONE" | sed 's/[^a-zA-Z0-9._-]/_/g')
ARCHIVE_NAME="alice_memory_pack_${SAFE_MILESTONE}_${TIMESTAMP}"

echo "🗄️  Creating archive snapshot for milestone: $MILESTONE"
echo "📁 Archive name: $ARCHIVE_NAME"

# Create archives directory if it doesn't exist
mkdir -p "$ARCHIVES_DIR"

# Create temporary directory for snapshot
TEMP_DIR=$(mktemp -d)
SNAPSHOT_DIR="$TEMP_DIR/$ARCHIVE_NAME"
mkdir -p "$SNAPSHOT_DIR"

# Copy all memory pack files
echo "📋 Copying memory pack files..."
cp "$MEMORY_PACK_DIR"/*.md "$SNAPSHOT_DIR/" 2>/dev/null || true
cp "$MEMORY_PACK_DIR"/*.jsonl "$SNAPSHOT_DIR/" 2>/dev/null || true
cp "$MEMORY_PACK_DIR"/*.json "$SNAPSHOT_DIR/" 2>/dev/null || true

# Copy documentation
if [ -d "$MEMORY_PACK_DIR/docs" ]; then
    echo "📚 Copying documentation..."
    cp -r "$MEMORY_PACK_DIR/docs" "$SNAPSHOT_DIR/"
fi

# Get git information
GIT_COMMIT=$(cd "$MEMORY_PACK_DIR" && git rev-parse HEAD 2>/dev/null || echo "Unknown")
GIT_BRANCH=$(cd "$MEMORY_PACK_DIR" && git branch --show-current 2>/dev/null || echo "Unknown")
GIT_TAG=$(cd "$MEMORY_PACK_DIR" && git describe --tags --exact-match 2>/dev/null || echo "None")

# Create snapshot metadata
cat > "$SNAPSHOT_DIR/SNAPSHOT_METADATA.json" << EOF
{
  "milestone": "$MILESTONE",
  "archive_name": "$ARCHIVE_NAME",
  "created_date": "$(date -u +"%Y-%m-%d %H:%M:%S UTC")",
  "git_commit": "$GIT_COMMIT",
  "git_branch": "$GIT_BRANCH",
  "git_tag": "$GIT_TAG",
  "files_archived": [
$(find "$SNAPSHOT_DIR" -type f -not -name "SNAPSHOT_METADATA.json" | sed 's|'"$SNAPSHOT_DIR"'/||' | sed 's/^/    "/' | sed 's/$/"/' | paste -sd ',' -)
  ],
  "archive_purpose": "Milestone backup for Alice Memory Pack evolution tracking"
}
EOF

# Create compressed archive
echo "🗜️  Creating compressed archive..."
cd "$TEMP_DIR"
tar -czf "$ARCHIVES_DIR/${ARCHIVE_NAME}.tar.gz" "$ARCHIVE_NAME"

# Generate checksum
echo "🔐 Generating checksum..."
cd "$ARCHIVES_DIR"
sha256sum "${ARCHIVE_NAME}.tar.gz" > "${ARCHIVE_NAME}.sha256"

# Create archive index entry
ARCHIVE_INDEX="$ARCHIVES_DIR/archive_index.json"
if [ ! -f "$ARCHIVE_INDEX" ]; then
    echo '{"archives": []}' > "$ARCHIVE_INDEX"
fi

# Add entry to index
python3 << EOF
import json
import os

index_file = "$ARCHIVE_INDEX"
with open(index_file, 'r') as f:
    index = json.load(f)

new_entry = {
    "milestone": "$MILESTONE",
    "archive_name": "$ARCHIVE_NAME",
    "created_date": "$(date -u +"%Y-%m-%d %H:%M:%S UTC")",
    "git_commit": "$GIT_COMMIT",
    "git_tag": "$GIT_TAG",
    "file_size": $(stat -c%s "$ARCHIVES_DIR/${ARCHIVE_NAME}.tar.gz"),
    "checksum": "$(cat "$ARCHIVES_DIR/${ARCHIVE_NAME}.sha256" | cut -d' ' -f1)"
}

index["archives"].append(new_entry)

with open(index_file, 'w') as f:
    json.dump(index, f, indent=2)
EOF

# Cleanup
rm -rf "$TEMP_DIR"

echo "✅ Archive created successfully!"
echo "📦 Archive: $ARCHIVES_DIR/${ARCHIVE_NAME}.tar.gz"
echo "🔐 Checksum: $ARCHIVES_DIR/${ARCHIVE_NAME}.sha256"
echo "📇 Index updated: $ARCHIVES_DIR/archive_index.json"
echo ""
echo "🔍 To verify archive integrity:"
echo "   cd $ARCHIVES_DIR && sha256sum -c ${ARCHIVE_NAME}.sha256"
echo ""
echo "📋 To list all archives:"
echo "   cat $ARCHIVES_DIR/archive_index.json | jq '.archives[] | {milestone, created_date, git_tag}'"
