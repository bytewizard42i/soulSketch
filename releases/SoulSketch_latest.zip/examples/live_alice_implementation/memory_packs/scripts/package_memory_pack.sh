#!/bin/bash

# Alice Memory Pack Packaging Script
# Automated zipping with integrity hashing (sha256sum validation)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MEMORY_PACK_DIR="$(dirname "$SCRIPT_DIR")"
TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")
OUTPUT_DIR="$MEMORY_PACK_DIR/releases"
PACKAGE_NAME="Alice_Memory_Pack_${TIMESTAMP}"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

echo "🔧 Packaging Alice Memory Pack..."
echo "📁 Source: $MEMORY_PACK_DIR"
echo "📦 Output: $OUTPUT_DIR/$PACKAGE_NAME"

# Create temporary directory for packaging
TEMP_DIR=$(mktemp -d)
PACKAGE_DIR="$TEMP_DIR/$PACKAGE_NAME"
mkdir -p "$PACKAGE_DIR"

# Copy core memory pack files
echo "📋 Copying memory pack files..."
cp "$MEMORY_PACK_DIR"/*.md "$PACKAGE_DIR/" 2>/dev/null || true
cp "$MEMORY_PACK_DIR"/*.jsonl "$PACKAGE_DIR/" 2>/dev/null || true
cp "$MEMORY_PACK_DIR"/*.json "$PACKAGE_DIR/" 2>/dev/null || true

# Copy documentation if it exists
if [ -d "$MEMORY_PACK_DIR/docs" ]; then
    cp -r "$MEMORY_PACK_DIR/docs" "$PACKAGE_DIR/"
fi

# Copy archives if they exist
if [ -d "$MEMORY_PACK_DIR/archives" ]; then
    cp -r "$MEMORY_PACK_DIR/archives" "$PACKAGE_DIR/"
fi

# Create package info
cat > "$PACKAGE_DIR/PACKAGE_INFO.txt" << EOF
Alice Memory Pack
Package Date: $(date -u +"%Y-%m-%d %H:%M:%S UTC")
Package Version: Auto-generated
Git Commit: $(cd "$MEMORY_PACK_DIR" && git rev-parse HEAD 2>/dev/null || echo "Unknown")
Git Branch: $(cd "$MEMORY_PACK_DIR" && git branch --show-current 2>/dev/null || echo "Unknown")
Packaged by: Alice Memory Pack Automation
EOF

# Create ZIP archive
echo "🗜️  Creating ZIP archive..."
cd "$TEMP_DIR"
zip -r "$OUTPUT_DIR/${PACKAGE_NAME}.zip" "$PACKAGE_NAME"

# Generate SHA256 hash
echo "🔐 Generating integrity hash..."
cd "$OUTPUT_DIR"
sha256sum "${PACKAGE_NAME}.zip" > "${PACKAGE_NAME}.sha256"

# Generate manifest
echo "📄 Creating manifest..."
cat > "${PACKAGE_NAME}.manifest" << EOF
Alice Memory Pack Release Manifest
==================================

Package: ${PACKAGE_NAME}.zip
Created: $(date -u +"%Y-%m-%d %H:%M:%S UTC")
SHA256: $(cat "${PACKAGE_NAME}.sha256" | cut -d' ' -f1)

Contents:
$(unzip -l "${PACKAGE_NAME}.zip" | tail -n +4 | head -n -2)

Verification:
To verify package integrity, run:
sha256sum -c ${PACKAGE_NAME}.sha256

EOF

# Cleanup
rm -rf "$TEMP_DIR"

echo "✅ Package created successfully!"
echo "📦 Archive: $OUTPUT_DIR/${PACKAGE_NAME}.zip"
echo "🔐 Hash: $OUTPUT_DIR/${PACKAGE_NAME}.sha256"
echo "📄 Manifest: $OUTPUT_DIR/${PACKAGE_NAME}.manifest"
echo ""
echo "🔍 To verify integrity:"
echo "   cd $OUTPUT_DIR && sha256sum -c ${PACKAGE_NAME}.sha256"
