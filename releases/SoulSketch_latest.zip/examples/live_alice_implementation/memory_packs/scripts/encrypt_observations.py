#!/usr/bin/env python3
"""
Alice Memory Pack - Runtime Observations Encryption
Encrypts sensitive runtime_observations.jsonl for secure sharing
"""

import os
import sys
import json
import getpass
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

def derive_key_from_password(password: str, salt: bytes) -> bytes:
    """Derive encryption key from password using PBKDF2"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key

def encrypt_file(input_path: str, output_path: str, password: str) -> dict:
    """Encrypt a file with password-based encryption"""
    # Generate random salt
    salt = os.urandom(16)
    
    # Derive key from password
    key = derive_key_from_password(password, salt)
    fernet = Fernet(key)
    
    # Read and encrypt file
    with open(input_path, 'rb') as f:
        data = f.read()
    
    encrypted_data = fernet.encrypt(data)
    
    # Create encrypted package
    package = {
        'version': '1.0',
        'algorithm': 'Fernet (AES 128)',
        'kdf': 'PBKDF2-SHA256',
        'iterations': 100000,
        'salt': base64.b64encode(salt).decode(),
        'encrypted_data': base64.b64encode(encrypted_data).decode(),
        'original_filename': os.path.basename(input_path)
    }
    
    # Write encrypted package
    with open(output_path, 'w') as f:
        json.dump(package, f, indent=2)
    
    return package

def decrypt_file(input_path: str, output_path: str, password: str) -> bool:
    """Decrypt an encrypted file"""
    try:
        # Read encrypted package
        with open(input_path, 'r') as f:
            package = json.load(f)
        
        # Extract components
        salt = base64.b64decode(package['salt'])
        encrypted_data = base64.b64decode(package['encrypted_data'])
        
        # Derive key and decrypt
        key = derive_key_from_password(password, salt)
        fernet = Fernet(key)
        decrypted_data = fernet.decrypt(encrypted_data)
        
        # Write decrypted file
        with open(output_path, 'wb') as f:
            f.write(decrypted_data)
        
        return True
    except Exception as e:
        print(f"❌ Decryption failed: {e}")
        return False

def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  Encrypt: python3 encrypt_observations.py encrypt [input_file] [output_file]")
        print("  Decrypt: python3 encrypt_observations.py decrypt [input_file] [output_file]")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "encrypt":
        input_file = sys.argv[2] if len(sys.argv) > 2 else "runtime_observations.jsonl"
        output_file = sys.argv[3] if len(sys.argv) > 3 else "runtime_observations.encrypted"
        
        if not os.path.exists(input_file):
            print(f"❌ Input file not found: {input_file}")
            sys.exit(1)
        
        print(f"🔐 Encrypting {input_file}...")
        password = getpass.getpass("Enter encryption password: ")
        confirm_password = getpass.getpass("Confirm password: ")
        
        if password != confirm_password:
            print("❌ Passwords don't match!")
            sys.exit(1)
        
        try:
            package = encrypt_file(input_file, output_file, password)
            print(f"✅ File encrypted successfully!")
            print(f"📁 Output: {output_file}")
            print(f"🔧 Algorithm: {package['algorithm']}")
            print(f"🔑 KDF: {package['kdf']} ({package['iterations']} iterations)")
        except Exception as e:
            print(f"❌ Encryption failed: {e}")
            sys.exit(1)
    
    elif command == "decrypt":
        input_file = sys.argv[2] if len(sys.argv) > 2 else "runtime_observations.encrypted"
        output_file = sys.argv[3] if len(sys.argv) > 3 else "runtime_observations_decrypted.jsonl"
        
        if not os.path.exists(input_file):
            print(f"❌ Input file not found: {input_file}")
            sys.exit(1)
        
        print(f"🔓 Decrypting {input_file}...")
        password = getpass.getpass("Enter decryption password: ")
        
        if decrypt_file(input_file, output_file, password):
            print(f"✅ File decrypted successfully!")
            print(f"📁 Output: {output_file}")
        else:
            sys.exit(1)
    
    else:
        print(f"❌ Unknown command: {command}")
        print("Use 'encrypt' or 'decrypt'")
        sys.exit(1)

if __name__ == "__main__":
    main()
