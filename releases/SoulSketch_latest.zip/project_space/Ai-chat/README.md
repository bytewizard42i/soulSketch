# AI Chat Log Protocol

- Location: `project_space/Ai-chat/`
- Naming: `YYYY-MM-DD-HHMM_commit-<shortsha>.md`
- Fields:
  - Title, Participants, Commit, Context Links
  - Emotional Resonance, Technical Notes, Philosophical Insights
  - Decisions, Next Steps
- Link to checkpoints via `project_space/CHECKPOINTS/` when applicable.
