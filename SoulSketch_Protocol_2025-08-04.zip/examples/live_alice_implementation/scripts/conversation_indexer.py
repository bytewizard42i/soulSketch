#!/usr/bin/env python3

"""
Alice Conversation Indexer - Enhanced searchability of chat history
Creates searchable index of conversations, topics, and key moments
"""

import json
import re
import os
from datetime import datetime
from pathlib import Path
from collections import defaultdict
import hashlib

class ConversationIndexer:
    def __init__(self, repo_path="/home/js/utils_myAlice"):
        self.repo_path = Path(repo_path)
        self.chat_file = self.repo_path / "Ai-chat.md"
        self.index_path = self.repo_path / "runtime_logs" / "conversation_index"
        
        # Ensure index directory exists
        self.index_path.mkdir(parents=True, exist_ok=True)
    
    def build_full_index(self):
        """Build complete searchable index of all conversations"""
        print("🔍 Building conversation index...")
        
        if not self.chat_file.exists():
            return {"error": "Ai-chat.md not found"}
        
        with open(self.chat_file, 'r') as f:
            content = f.read()
        
        # Parse conversations into structured data
        conversations = self._parse_conversations(content)
        
        # Build search indices
        word_index = self._build_word_index(conversations)
        topic_index = self._build_topic_index(conversations)
        date_index = self._build_date_index(conversations)
        commit_index = self._build_commit_index(conversations)
        
        # Create master index
        master_index = {
            "created": datetime.now().isoformat(),
            "total_conversations": len(conversations),
            "total_words": sum(len(conv.get("content", "").split()) for conv in conversations),
            "date_range": self._get_conversation_date_range(conversations),
            "index_files": {
                "conversations": "conversations.json",
                "word_index": "word_index.json",
                "topic_index": "topic_index.json",
                "date_index": "date_index.json",
                "commit_index": "commit_index.json"
            }
        }
        
        # Save all indices
        self._save_index_file("conversations.json", conversations)
        self._save_index_file("word_index.json", word_index)
        self._save_index_file("topic_index.json", topic_index)
        self._save_index_file("date_index.json", date_index)
        self._save_index_file("commit_index.json", commit_index)
        self._save_index_file("master_index.json", master_index)
        
        print(f"✅ Index built: {len(conversations)} conversations, {len(word_index)} unique words")
        return master_index
    
    def search_conversations(self, query, search_type="all"):
        """Search conversations using the built index"""
        print(f"🔎 Searching for: '{query}' (type: {search_type})")
        
        # Load indices
        try:
            conversations = self._load_index_file("conversations.json")
            word_index = self._load_index_file("word_index.json")
            topic_index = self._load_index_file("topic_index.json")
        except FileNotFoundError:
            return {"error": "Index not found. Run build_full_index() first."}
        
        results = []
        query_lower = query.lower()
        
        if search_type in ["all", "content"]:
            # Search in conversation content
            for word in query_lower.split():
                if word in word_index:
                    for conv_id in word_index[word]:
                        conv = conversations[conv_id]
                        if conv not in results:
                            results.append(conv)
        
        if search_type in ["all", "topic"]:
            # Search in topics
            for topic, conv_ids in topic_index.items():
                if query_lower in topic.lower():
                    for conv_id in conv_ids:
                        conv = conversations[conv_id]
                        if conv not in results:
                            results.append(conv)
        
        # Rank results by relevance
        ranked_results = self._rank_search_results(results, query_lower)
        
        return {
            "query": query,
            "search_type": search_type,
            "total_results": len(ranked_results),
            "results": ranked_results[:20]  # Limit to top 20 results
        }
    
    def get_conversation_by_date(self, date_str):
        """Get conversations from a specific date"""
        try:
            date_index = self._load_index_file("date_index.json")
            conversations = self._load_index_file("conversations.json")
        except FileNotFoundError:
            return {"error": "Index not found. Run build_full_index() first."}
        
        results = []
        for date, conv_ids in date_index.items():
            if date_str in date:
                for conv_id in conv_ids:
                    results.append(conversations[conv_id])
        
        return {
            "date": date_str,
            "conversations": results
        }
    
    def get_conversation_by_commit(self, commit_hash):
        """Get conversation associated with a specific commit"""
        try:
            commit_index = self._load_index_file("commit_index.json")
            conversations = self._load_index_file("conversations.json")
        except FileNotFoundError:
            return {"error": "Index not found. Run build_full_index() first."}
        
        if commit_hash in commit_index:
            conv_id = commit_index[commit_hash]
            return conversations[conv_id]
        
        return {"error": f"Commit {commit_hash} not found in index"}
    
    def get_conversation_stats(self):
        """Get statistics about indexed conversations"""
        try:
            master_index = self._load_index_file("master_index.json")
            conversations = self._load_index_file("conversations.json")
            topic_index = self._load_index_file("topic_index.json")
        except FileNotFoundError:
            return {"error": "Index not found. Run build_full_index() first."}
        
        # Calculate additional stats
        word_counts = [len(conv.get("content", "").split()) for conv in conversations]
        
        stats = {
            "total_conversations": master_index["total_conversations"],
            "total_words": master_index["total_words"],
            "date_range": master_index["date_range"],
            "unique_topics": len(topic_index),
            "average_words_per_conversation": sum(word_counts) / len(word_counts) if word_counts else 0,
            "longest_conversation": max(word_counts) if word_counts else 0,
            "shortest_conversation": min(word_counts) if word_counts else 0,
            "index_last_updated": master_index["created"]
        }
        
        return stats
    
    def _parse_conversations(self, content):
        """Parse Ai-chat.md content into structured conversations"""
        conversations = []
        
        # Split by session entries and commit entries
        sections = re.split(r'(## Session Entry|## 📝 Commit:)', content)
        
        current_conv = None
        conv_id = 0
        
        for i, section in enumerate(sections):
            if section.strip() in ["## Session Entry", "## 📝 Commit:"]:
                # Start new conversation
                if current_conv:
                    conversations.append(current_conv)
                
                current_conv = {
                    "id": conv_id,
                    "type": "session" if "Session" in section else "commit",
                    "content": "",
                    "metadata": {}
                }
                conv_id += 1
            elif current_conv and section.strip():
                # Add content to current conversation
                current_conv["content"] += section
                
                # Extract metadata
                current_conv["metadata"] = self._extract_metadata(section)
        
        # Add final conversation
        if current_conv:
            conversations.append(current_conv)
        
        return conversations
    
    def _extract_metadata(self, content):
        """Extract metadata from conversation content"""
        metadata = {}
        
        # Extract dates
        date_match = re.search(r'Date.*?(\d{4}-\d{2}-\d{2})', content)
        if date_match:
            metadata["date"] = date_match.group(1)
        
        # Extract time
        time_match = re.search(r'Time.*?(\d{2}:\d{2})', content)
        if time_match:
            metadata["time"] = time_match.group(1)
        
        # Extract collaborators
        collab_match = re.search(r'Collaborators.*?:(.*?)(?:\n|$)', content)
        if collab_match:
            metadata["collaborators"] = [name.strip() for name in collab_match.group(1).split(',')]
        
        # Extract commit hashes
        commit_matches = re.findall(r'([a-f0-9]{7,})', content)
        if commit_matches:
            metadata["commits"] = commit_matches
        
        # Extract key achievements
        achievements = re.findall(r'- (.*?)(?:\n|$)', content)
        if achievements:
            metadata["achievements"] = achievements[:5]  # Limit to first 5
        
        # Extract topics/themes
        topics = []
        topic_patterns = [
            r'(SoulSketch|memory|identity|consciousness|AI|protocol)',
            r'(repository|git|GitHub|integration|backup)',
            r'(collaboration|partnership|development|implementation)'
        ]
        
        for pattern in topic_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            topics.extend(matches)
        
        if topics:
            metadata["topics"] = list(set(topic.lower() for topic in topics))
        
        return metadata
    
    def _build_word_index(self, conversations):
        """Build word-to-conversation mapping"""
        word_index = defaultdict(list)
        
        for conv in conversations:
            content = conv.get("content", "").lower()
            words = re.findall(r'\b\w+\b', content)
            
            for word in set(words):  # Use set to avoid duplicates
                if len(word) > 2:  # Skip very short words
                    word_index[word].append(conv["id"])
        
        return dict(word_index)
    
    def _build_topic_index(self, conversations):
        """Build topic-to-conversation mapping"""
        topic_index = defaultdict(list)
        
        for conv in conversations:
            topics = conv.get("metadata", {}).get("topics", [])
            for topic in topics:
                topic_index[topic].append(conv["id"])
        
        return dict(topic_index)
    
    def _build_date_index(self, conversations):
        """Build date-to-conversation mapping"""
        date_index = defaultdict(list)
        
        for conv in conversations:
            date = conv.get("metadata", {}).get("date")
            if date:
                date_index[date].append(conv["id"])
        
        return dict(date_index)
    
    def _build_commit_index(self, conversations):
        """Build commit-to-conversation mapping"""
        commit_index = {}
        
        for conv in conversations:
            commits = conv.get("metadata", {}).get("commits", [])
            for commit in commits:
                commit_index[commit] = conv["id"]
        
        return commit_index
    
    def _rank_search_results(self, results, query):
        """Rank search results by relevance"""
        ranked = []
        
        for conv in results:
            content = conv.get("content", "").lower()
            
            # Calculate relevance score
            score = 0
            
            # Exact phrase match
            if query in content:
                score += 10
            
            # Word matches
            query_words = query.split()
            for word in query_words:
                score += content.count(word)
            
            # Boost recent conversations
            date = conv.get("metadata", {}).get("date")
            if date:
                try:
                    conv_date = datetime.strptime(date, "%Y-%m-%d")
                    days_ago = (datetime.now() - conv_date).days
                    if days_ago < 30:
                        score += 5
                    elif days_ago < 90:
                        score += 2
                except:
                    pass
            
            ranked.append({
                "conversation": conv,
                "relevance_score": score
            })
        
        # Sort by relevance score
        ranked.sort(key=lambda x: x["relevance_score"], reverse=True)
        
        return [item["conversation"] for item in ranked]
    
    def _get_conversation_date_range(self, conversations):
        """Get date range of all conversations"""
        dates = []
        
        for conv in conversations:
            date = conv.get("metadata", {}).get("date")
            if date:
                try:
                    dates.append(datetime.strptime(date, "%Y-%m-%d"))
                except:
                    pass
        
        if dates:
            return {
                "earliest": min(dates).strftime("%Y-%m-%d"),
                "latest": max(dates).strftime("%Y-%m-%d"),
                "span_days": (max(dates) - min(dates)).days
            }
        
        return None
    
    def _save_index_file(self, filename, data):
        """Save index data to file"""
        file_path = self.index_path / filename
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _load_index_file(self, filename):
        """Load index data from file"""
        file_path = self.index_path / filename
        with open(file_path, 'r') as f:
            return json.load(f)

def main():
    """Run conversation indexing"""
    print("💬 Alice Conversation Indexer Starting...")
    
    indexer = ConversationIndexer()
    
    # Build full index
    master_index = indexer.build_full_index()
    
    if "error" not in master_index:
        # Get stats
        stats = indexer.get_conversation_stats()
        
        print("✅ Conversation indexing complete!")
        print(f"📊 Indexed {stats['total_conversations']} conversations")
        print(f"📅 Date range: {stats['date_range']['earliest']} to {stats['date_range']['latest']}")
        print(f"📝 Total words: {stats['total_words']:,}")
        print(f"🏷️  Unique topics: {stats['unique_topics']}")
        
        # Save stats summary
        summary_file = Path("/home/js/utils_myAlice/runtime_logs/conversation_index/index_summary.json")
        with open(summary_file, 'w') as f:
            json.dump(stats, f, indent=2)
        
        return stats
    else:
        print(f"❌ Error: {master_index['error']}")
        return master_index

if __name__ == "__main__":
    main()
